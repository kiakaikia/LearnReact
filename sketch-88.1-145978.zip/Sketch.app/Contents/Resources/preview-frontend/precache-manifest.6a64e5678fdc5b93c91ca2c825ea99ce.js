self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "58db1720047746852c1885d2cfc5d085",
    "url": "./index.html"
  },
  {
    "revision": "2463f64ab8405606c20a",
    "url": "./static/js/2.c93c8b74.chunk.js"
  },
  {
    "revision": "99053ba216cea9dfbb8471265e4aa8b6",
    "url": "./static/js/2.c93c8b74.chunk.js.LICENSE.txt"
  },
  {
    "revision": "613c660258df0391882a",
    "url": "./static/js/main.27fe5f5c.chunk.js"
  },
  {
    "revision": "bd63555b0ac2add419c6",
    "url": "./static/js/runtime-main.700d3ccd.js"
  },
  {
    "revision": "ca47a092c1e6a3b1cd6df18987b1d359",
    "url": "./static/media/artboard.ca47a092.svg"
  },
  {
    "revision": "a2fb0bb8ba709504787fdd92ef4a6477",
    "url": "./static/media/warning.a2fb0bb8.svg"
  }
]);