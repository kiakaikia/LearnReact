# `buffer` for Sketch

All the [nodejs buffer](https://nodejs.org/api/buffer.html) API is available.

Additionally, you can create a `Buffer` from an `NSData` (`Buffer.from(nsdata)`) as well as getting an `NSData` from a `Buffer` (`buffer.toNSData()`).
