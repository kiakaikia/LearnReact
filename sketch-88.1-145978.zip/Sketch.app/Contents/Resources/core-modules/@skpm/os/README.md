# `os` for Sketch

All the [nodejs os](https://nodejs.org/api/os.html) API is available but some might just be stubs.
